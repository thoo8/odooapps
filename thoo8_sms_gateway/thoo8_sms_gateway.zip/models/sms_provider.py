from odoo import models, fields, api, _
from odoo.exceptions import UserError, _logger
import json, requests
from odoo import api, SUPERUSER_ID


class SmsProviderField(models.Model):
    _name = "thoo8.sms.provider.field"
    _description = "Provider Field"

    provider_id = fields.Many2one("thoo8.sms.provider", string="Provider", required=True)
    field_name = fields.Char("Field Name", required=True, help="Name used in Python")
    api_key_name = fields.Char("API Variable Name", required=True, help="Actual variable name required by the provider")
    value = fields.Char("Default Value", help="Value to send for this variable")


class SmsProvider(models.Model):
    _name = "thoo8.sms.provider"
    _description = "SMS Provider"

    name = fields.Char("Provider Name", required=True)
    api_url = fields.Char("API URL", required=True)
    active = fields.Boolean(default=True)
    provider_fields = fields.One2many("thoo8.sms.provider.field", "provider_id", string="Provider Fields")

    # المتغيرات الخاصة بالرقم والنص
    recipient_number_field = fields.Char(
        string="Recipient Number Variable",
        help="The actual variable name to send the recipient number to the API (e.g., numbers, to)"
    )
    message_field = fields.Char(
        string="Message Variable",
        help="The actual variable name to send the message text to the API (e.g., msg, message)"
    )

    # حقل Extra Parameters
    extra_params = fields.Text("Extra Parameters (JSON)", help="Add additional dynamic variables in JSON format")
    test_number = fields.Char("Test Number", help="Phone number in international format, e.g., 9665XXXXXXX")

    def action_open_test_wizard(self):
        self.ensure_one()
        return {
            "name": _("Test SMS"),
            "type": "ir.actions.act_window",
            "res_model": "thoo8.sms.test.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_provider_id": self.id,
            }
        }

    def _log_sms(self, phone, message, status="pending", response=None):
        """Save SMS log with independent commit"""
        with api.Environment.manage():
            # افتح كرسر جديد مستقل
            new_cr = self.pool.cursor()
            try:
                env2 = api.Environment(new_cr, SUPERUSER_ID, {})
                env2['thoo8.sms.log'].create({
                    'provider_id': self.id,
                    'to': phone,
                    'message': message,
                    'status': status,
                    'response_text': response or "",
                })
                new_cr.commit()  # فقط لهذا الكرسر
            except Exception as e:
                new_cr.rollback()
                _logger.error("Failed to save SMS log: %s", e)
            finally:
                new_cr.close()

    def action_test_sms(self):
        if not self.test_number:
            raise UserError("Please enter a phone number for testing.")

        test_message = f"Test SMS from {self.name}"
        try:
            response = self.send_sms(self.test_number, test_message)
        except Exception as e:
            raise UserError(f"Error sending test SMS: {str(e)}")

        raise UserError(f"Provider response: {response}")

    def send_sms(self, phone, message):
        payload = {}

        # إضافة الحقول الديناميكية من provider_fields
        for f in self.provider_fields:
            payload[f.api_key_name] = f.value

        # إضافة أي متغيرات إضافية من extra_params (JSON)
        if hasattr(self, 'extra_params') and self.extra_params:
            try:
                extra = json.loads(self.extra_params)
                payload.update(extra)
            except Exception:
                raise UserError("Invalid JSON in Extra Parameters")

        # أرقام المستلمين ونص الرسالة حسب متغيرات المزود
        if self.recipient_number_field:
            payload[self.recipient_number_field] = phone
        else:
            payload['numbers'] = phone

        if self.message_field:
            payload[self.message_field] = message
        else:
            payload['msg'] = message

        headers = {"Content-Type": "application/json"}

        try:
            response = requests.post(self.api_url, data=json.dumps(payload), headers=headers, timeout=15)
            try:
                response_json = response.json()
            except Exception:
                response_json = {"error": response.text}

            # تسجيل الرسالة بنجاح
            self._log_sms(phone, message, status=str(response.status_code), response=json.dumps(response_json))

            return response_json

        except requests.exceptions.RequestException as e:
            # تسجيل الفشل أيضًا بصلاحيات sudo
            self._log_sms(phone, message, status='Failed', response=str(e))

            raise UserError(f"Failed to send SMS: {str(e)}")