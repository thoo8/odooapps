from odoo import models, fields, api
from odoo.exceptions import UserError
from jinja2 import Environment, BaseLoader


class SmsTestWizard(models.TransientModel):
    _name = "thoo8.sms.test.wizard"
    _description = "SMS Test Wizard"

    provider_id = fields.Many2one("thoo8.sms.provider", string="Provider", required=True)
    template_id = fields.Many2one("thoo8.sms.template", string="SMS Template", required=True)
    template_model = fields.Many2one("ir.model", string="Template Module", compute="_compute_template_model")
    test_number = fields.Char("Test Number", required=True,
                              default=lambda self: self.env.user.partner_id.phone or self.env.user.partner_id.mobile or '')

    @api.depends('template_id')
    def _compute_template_model(self):
        for rec in self:
            rec.template_model = rec.template_id.model_id.id if rec.template_id else False

    def action_send_test_sms(self):
        self.ensure_one()

        # جلب أول سجل من الموديل المرتبط بالقالب
        record = None
        if self.template_id.model_id:
            record = self.env[self.template_id.model_id.model].search([], limit=1)

        # Jinja2 rendering
        env = Environment(loader=BaseLoader())
        try:
            template = env.from_string(self.template_id.body or "")
            message = template.render(object=record) if record else template.render()
        except Exception as e:
            raise UserError(f"خطأ في توليد الرسالة من القالب:\n{str(e)}")

        print(message)
        if not message:
            raise UserError("الناتج من القالب فارغ.")

        # إرسال الرسالة عبر المزود
        response = self.provider_id.send_sms(self.test_number, message)

        raise UserError(f"تم إرسال الرسالة التجريبية.\nResponse: {response}")
